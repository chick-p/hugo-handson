---
title: "タスクの更新"
date: 2020-02-03T14:27:40+09:00
---

### URL

`https://example.com/api/v1/tasks/{id}`

### メソッド

PUT

### リクエストパラメータ

|プロパティ |型 |必須 |説明
|:--|:--|:--|:--
|name |String |◯ |タスク名です
|due |Date | |タスクの締切日です
|description |String | |タスクの説明です
