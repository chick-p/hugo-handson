---
title: "Tasks"
date: 2020-02-03T14:27:24+09:00
---

This API is for management tasks.
