---
title: "更新任务"
date: 2020-02-03T14:27:40+09:00
---

### URL

`https://example.com/api/v1/tasks/{id}`

### HTTP 方法

PUT

### 请求参数

|参数名称 |要指定的值 |必须 |说明
|:--|:--|:--|:--
|name |String |必须 |任务名称
|due |Date | |由于任务
|description |String | |任务描述
